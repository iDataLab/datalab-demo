# [18.49.4](https://github.intel.com/DataLab/datalab-demo/tree/18.49.4)

* Initialize project
* Create setup script for project packaging
* Use MIT License