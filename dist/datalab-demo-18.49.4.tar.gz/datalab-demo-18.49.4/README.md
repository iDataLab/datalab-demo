# datalab-demo
This is a demo python library

# Prerequisites

```buildoutcfg
python -m pip install setuptools sphinx
```

# Installation

## Latest Version

```buildoutcfg
python -m pip install git+https://github.intel.com/datalab/datalab-demo
```

# Packaging

```buildoutcfg
python setup.py sdist
```

# [ChangeLog](CHANGELOG.md)