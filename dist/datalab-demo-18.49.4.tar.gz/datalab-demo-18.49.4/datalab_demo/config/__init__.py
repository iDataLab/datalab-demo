#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Default project configurations.

"""
import os

#: Project base path
BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
